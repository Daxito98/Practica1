## Install the project packages

npm install

## Create or reset the Database (model)

node model.js --create

## Check the Database with a simple query

node model.js

## Run de server

npm start

## Check the API in the browser

http://localhost:9000/graphql

## START your PROJECT!!


## Coments ##

- app ID -> application-0-xniet
- URL endpoint Mongo.DB -> https://data.mongodb-api.com/app/data-tllwe/endpoint/data/beta
- API-Key -> A8KSQRoHfozdrC6pwUNDt0wjo1HlSlntu0iIENziysuF1XcJrmv6orXpSynr9z5q

- Atlas AWS Account ARN: arn:aws:iam::536727724300:root 
- Your unique External ID: 2112ac0a-e67f-4722-97ab-3642af8dd00b
